from setuptools import setup

package_name = 'pepper_demo'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md', 'instructions.txt']),
        ('share/' + package_name + '/urdf', ['urdf/pepper.urdf']),
        ('share/' + package_name + '/launch', ['pepper_demo/launch/pepper_demo.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='you@example.com',
    description='Uni demo: Pepper robot in RViz2 (single-command launch).',
    license='BSD-3-Clause',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'joint_state_executor = pepper_demo.joint_state_executor:main',
            'trajectory_sender = pepper_demo.trajectory_sender:main',
        ],
    },
)
