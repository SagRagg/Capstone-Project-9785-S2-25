# Pepper RViz2 Demo (Uni Project)

This package demonstrates two ROS 2 nodes communicating to move Pepper in RViz2:

- `trajectory_sender` publishes random joint goals (within Pepper limits)
- `joint_state_executor` interpolates those goals and publishes `/joint_states`
- `robot_state_publisher` uses the provided URDF to publish TF
- `rviz2` displays Pepper (Fixed Frame: `base_link`)

## Quick start
```
cd ~/ros2_pepper_ws/src
unzip pepper_demo.zip
cd ~/ros2_pepper_ws
colcon build --symlink-install --packages-select pepper_demo
source install/setup.bash
ros2 launch pepper_demo pepper_demo.launch.py
```
If Pepper doesn't appear, set RViz Fixed Frame to `base_link` and add **RobotModel** + **TF**.
