#!/usr/bin/env python3
import time
import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory
from sensor_msgs.msg import JointState

STARTUP_JOINTS = [
    "HeadYaw","HeadPitch",
    "HipRoll","HipPitch","KneePitch",
    "LShoulderPitch","LShoulderRoll","LElbowYaw","LElbowRoll","LWristYaw","LHand",
    "RShoulderPitch","RShoulderRoll","RElbowYaw","RElbowRoll","RWristYaw","RHand",
]

class JointStateExecutor(Node):
    def __init__(self):
        super().__init__('joint_state_executor')
        self.q = {}
        self.goal = None
        self.goal_start_time = None
        self.goal_duration = 1.0

        self.sub = self.create_subscription(JointTrajectory, '/pepper/joint_trajectory', self.on_traj, 10)
        self.pub = self.create_publisher(JointState, '/joint_states', 10)
        self.timer = self.create_timer(1.0/30.0, self.step)  # 30 Hz

        for name in STARTUP_JOINTS:
            self.q[name] = 0.0
        self.publish_once()
        self.get_logger().info("Published initial zero pose.")

    def on_traj(self, traj: JointTrajectory):
        if not traj.points:
            return
        pt = traj.points[0]
        for name in traj.joint_names:
            self.q.setdefault(name, 0.0)
        self.goal = dict(zip(traj.joint_names, pt.positions))
        self.goal_duration = pt.time_from_start.sec + pt.time_from_start.nanosec * 1e-9
        if self.goal_duration <= 0.0:
            self.goal_duration = 0.001
        self.goal_start_time = time.time()
        self.get_logger().info(f"Received goal over {self.goal_duration:.2f}s")

    def step(self):
        now = time.time()
        if self.goal is not None and self.goal_start_time is not None:
            t = (now - self.goal_start_time) / self.goal_duration
            t = max(0.0, min(1.0, t))
            for name, q_goal in self.goal.items():
                q0 = self.q.get(name, 0.0)
                self.q[name] = q0 + (q_goal - q0) * t
            if t >= 1.0:
                self.goal = None
                self.goal_start_time = None

        if self.q:
            self.publish_once()

    def publish_once(self):
        js = JointState()
        js.header.stamp = self.get_clock().now().to_msg()
        js.name = list(self.q.keys())
        js.position = [self.q[n] for n in js.name]
        self.pub.publish(js)

def main(args=None):
    rclpy.init(args=args)
    node = JointStateExecutor()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
