#!/usr/bin/env python3
import random
import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration

LIMITS = {
    "HeadYaw":        (-2.086,  2.086),
    "HeadPitch":      (-0.707,  0.430),
    "HipRoll":        (-0.515,  0.515),
    "HipPitch":       (-1.038,  1.038),
    "KneePitch":      (-0.515,  0.515),
    "LShoulderPitch": (-2.086,  2.086),
    "LShoulderRoll":  ( 0.009,  1.562),
    "LElbowYaw":      (-2.086,  2.086),
    "LElbowRoll":     (-1.562, -0.009),
    "LWristYaw":      (-1.824,  1.824),
    "LHand":          ( 0.000,  1.000),
    "RShoulderPitch": (-2.086,  2.086),
    "RShoulderRoll":  (-1.562, -0.009),
    "RElbowYaw":      (-2.086,  2.086),
    "RElbowRoll":     ( 0.009,  1.562),
    "RWristYaw":      (-1.824,  1.824),
    "RHand":          ( 0.000,  1.000),
}
JOINTS = list(LIMITS.keys())

class TrajectorySender(Node):
    def __init__(self):
        super().__init__('trajectory_sender')
        self.pub = self.create_publisher(JointTrajectory, '/pepper/joint_trajectory', 10)
        self.timer = self.create_timer(2.0, self.send_random_goal)  # new target every 2 s
        self.get_logger().info("Randomising joints: " + ", ".join(JOINTS))

    def sample(self, name: str) -> float:
        lo, hi = LIMITS[name]
        margin = 0.10 * (hi - lo)  # gentle demo
        lo2, hi2 = lo + margin, hi - margin
        if hi2 <= lo2:
            return 0.5 * (lo + hi)
        return random.uniform(lo2, hi2)

    def send_random_goal(self):
        traj = JointTrajectory()
        traj.joint_names = JOINTS

        pt = JointTrajectoryPoint()
        pt.positions = [self.sample(n) for n in JOINTS]
        pt.time_from_start = Duration(sec=1, nanosec=0)  # reach in ~1 s
        traj.points = [pt]

        self.pub.publish(traj)
        self.get_logger().info("Random goal: " + ", ".join(
            f"{n}={v:.2f}" for n, v in zip(JOINTS, pt.positions)
        ))

def main(args=None):
    rclpy.init(args=args)
    node = TrajectorySender()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
