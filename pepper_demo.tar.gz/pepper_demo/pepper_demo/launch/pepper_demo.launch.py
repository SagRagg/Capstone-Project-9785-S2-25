#!/usr/bin/env python3
from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg = get_package_share_directory('pepper_demo')
    urdf = open(pkg + "/urdf/pepper.urdf").read()

    return LaunchDescription([
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': urdf, 'publish_frequency': 30.0}]
        ),
        Node(
            package='pepper_demo',
            executable='joint_state_executor',
            name='joint_state_executor',
            output='screen'
        ),
        Node(
            package='pepper_demo',
            executable='trajectory_sender',
            name='trajectory_sender',
            output='screen'
        ),
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['--enable-fps'],
            parameters=[{'robot_description': urdf}]
        ),
    ])
